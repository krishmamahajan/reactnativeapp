import React, { useState } from "react";
import { View, Picker, StyleSheet, Text, AsyncStorage } from "react-native";
import { Button, Title } from "react-native-paper";
import QRCode from 'react-qr-code';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { Actions } from "react-native-router-flux";
import {Body, Header, Icon, Left, Right
} from 'native-base';


export default function qrgenerater() {

  const [name, setName] = useState('');
  
  AsyncStorage.getItem("user").then((data) => {
    // let user = data;
    setName(data);
})

if({name} == ''){
  Actions.login()
  }

    const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
 
    const showDatePicker = () => {
      setDatePickerVisibility(true);
    };
   
    const hideDatePicker = () => {
      setDatePickerVisibility(false);
    };
   
    const handleConfirm = (date) => {
      console.warn("A date has been picked: ", date);
      hideDatePicker();
    };

const logout = () =>{
  AsyncStorage.setItem("user", '' );
  Actions.login()
}

  const [selectedValue, setSelectedValue] = useState();
  return (
    <View style={styles.container}>


<Header>
      <Left>



<Icon ios='ios-menu' android="md-menu" style={{fontSize: 30, color:'#fff'}}/>

</Left>
<Body>
    <Text style={{textAlign:'center', color:'#fff'}}>Teacher Screen</Text>
    
</Body>
<Right>
<Text style={{textAlign:'right', color:'#fff'}} onPress={logout}>LOG OUT</Text>

</Right>

      </Header>
  

  <Text style={styles.welcome}>
      <Text >Welcome</Text>
      <Text> {name} </Text>
      </Text>


<View style={styles.content}>

<Title>Generate QR Code</Title>
<QRCode
          value ="Test"
        />



        <Text  style={{ margin:10 }}>Select Class: </Text>
      <Picker
        selectedValue={selectedValue}
        style={{ height: 30, width: 150, margin:10 }}
        onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
      >
        <Picker.Item label="BA" value="BA" />
        <Picker.Item label="MA" value="MA" />
        <Picker.Item label="MBA" value="MBA" />
        <Picker.Item label="BCA" value="BCA" />
        <Picker.Item label="MCA" value="MCA" />
      </Picker>
      <Text>Select Subject: </Text>
      <Picker
        selectedValue={selectedValue}
        style={{ height: 30, width: 150 }}
        onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
      >
        <Picker.Item label="English" value="English" />
        <Picker.Item label="Math" value="Math" />
        <Picker.Item label="Java" value="java" />
        <Picker.Item label="JavaScript" value="js" />
        <Picker.Item label="PHP" value="PHP" />

      </Picker>
      <Text>Select Date&Time: </Text>
      <Picker
        selectedValue={selectedValue}
        style={{ height: 30, width: 150 }}
        onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}
      >
        <Picker.Item label="Java" value="java" />
        <Picker.Item label="JavaScript" value="js" />
        <Picker.Item label="PHP" value="PHP" />
      </Picker>
<Text onPress={() =>alert("Datepicker Modal")}>Show Date Picker</Text>
      <Button title="Show Date Picker" onPress={() =>alert("Datepicker Modal")} />
      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />


      <Button style={styles.button} mode="contained" onPress={() => alert("QR Generated")}>
Generate QR
  </Button>
  </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingTop: 40,
    alignItems: "center"
  },
  button: {
    width: '60%',
    paddingTop: 8,
    marginTop: 10,
    paddingBottom: 8,
    backgroundColor: '#006aff',
    marginBottom: 20,
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
    fontWeight:'bold'
  }
});