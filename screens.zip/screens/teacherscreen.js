

import React, {  useState } from 'react';
import {View, Text, StyleSheet,AsyncStorage, TouchableOpacity} from 'react-native';
import {Body, Header, Icon, Left, Right, Button, Card} from 'native-base';
//import { Card } from 'react-native-paper';

 import { Actions } from 'react-native-router-flux';
 
 
const Teacherscreen = (props)=> {

  const [name, setName] = useState('');
  
  AsyncStorage.getItem("user").then((data) => {
    // let user = data;
    setName(data);
})


const logout = () =>{
 
  AsyncStorage.removeItem("user")
        .then(() => alert('success'));
  Actions.login()
}

  return (
    
    <View style={styles.container}>
       
       
    <Header>
                    <Left>


                    <Button transparent onPress={() => Actions.drawer()}>
<Icon name='menu' />
</Button>
                        {/* <Icon name="menu"  ios='ios-menu' android="md-menu" style={{fontSize: 30, color:'#fff'}} onPress={() => alert("Hii")}/> */}
                    </Left>
                    <Body>
                        <Text>Teacher Screen</Text>
                        
                    </Body>
                    <Right>
                    <Text style={{textAlign:'right', color:'#fff'}} onPress={logout}>LOG OUT</Text>


                    </Right>
                    
                </Header>
<View style={styles.content}>
      <Text style={styles.welcome}>Teacher screen!</Text>
      <Text style={styles.welcome}>
      <Text >Welcome</Text>
      <Text> {name} </Text>
      </Text>
      
      <Text>Teacher Screen</Text>
      

      <Text style={styles.textstyle} onPress={()=> Actions.select()}>Generate QR Code</Text>
      <Text style={styles.textstyle} onPress={()=> Actions.addsubject()}>Add Subject</Text>

      <Text style={styles.textstyle} onPress={()=> Actions.studentsignup()}>Add Student</Text>
  <Text style={styles.textstyle} onPress={()=> Actions.addclass()}>Add Class</Text>
  <View style={{flexDirection:"row", flex:1, marginRight:50}}>
  <Card style={styles.mycard}   >
    <View style={styles.cardView} >
      <TouchableOpacity  onPress={()=> Actions.studentsignup()}>
    <Icon
     name="person-add"  ios='ios-person-add' android="md-person-add" style={{fontSize: 30}} />
       <Text
      
       style={styles.welcome}>Add Student</Text> 
   </TouchableOpacity>
    </View>
    
   </Card>
        <Card style={styles.mycard}>
    <View style={styles.cardView}>
    <TouchableOpacity  onPress={()=> Actions.studentlist()}>
    <Icon
                    name="paper"  ios='ios-paper' android="md-paper" style={{fontSize: 30}} />
       
       <Text style={styles.welcome} >View All Students</Text>
       </TouchableOpacity>
    </View>
    
   </Card>
   <Card style={styles.mycard}   >
    <View style={styles.cardView} >
      <TouchableOpacity  onPress={() => Actions.studentprofile()}>
    <Icon
     name="person"  ios='ios-person' android="md-person" style={{fontSize: 30}} />
       <Text
      
       style={styles.welcome}> View Profile</Text> 
   </TouchableOpacity>
    </View>
    
   </Card>
   </View>
   </View>
    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
    fontWeight: 'bold'
  },
  mycard:{
    marginRight:30,
    width:"50%",
    padding:10,
    height:"20%",
    borderRadius:5,
    shadowColor: "#fff",
    shadowOpacity:0.5,
    shadowRadius:5,

   
   
},
content: {
  flex: 1,
  marginHorizontal:20,
  backgroundColor: '#F5FCFF',
},
cardView:{
   flexDirection:"row",
   padding:5
  },
  textstyle: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
    
  }
});
export default Teacherscreen;

