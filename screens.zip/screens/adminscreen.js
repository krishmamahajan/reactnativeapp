

import React, {  useState } from 'react';
import {View, Text, StyleSheet,AsyncStorage, TouchableOpacity} from 'react-native';
import {Body, Header, Icon, Left, Right, Button, Card} from 'native-base';

 import { Actions } from 'react-native-router-flux';
 
 
const Principalscreen = (props)=> {

  const [name, setName] = useState('');
  
  AsyncStorage.getItem("user").then((data) => {
    // let user = data;
    setName(data);
})


const logout = () =>{
 
  AsyncStorage.removeItem("user")
        .then(() => alert('success'));
  Actions.login()
}

  return (
    
    <View style={styles.container}>
       
       
        <Header>
         <Left>
        <Button transparent onPress={() => Actions.drawer()}>
        <Icon name='menu' />
        </Button>
            </Left>
            <Body>
        <Text>Principal Screen</Text>
                                
            </Body>
            <Right>
            <Text style={{textAlign:'right'}} onPress={logout}>LOG OUT</Text>
        </Right>
                        
        </Header>

      <Text style={styles.welcome}>Principal screen!</Text>
      <Text style={styles.welcome}>
      <Text >Welcome</Text>
      <Text> {name} </Text>
      </Text>
      
      <Text>Principal Screen</Text>
      <Text style={styles.textstyle} onPress={()=> Actions.select()}>Generate QR Code</Text>
      <Text style={styles.textstyle} onPress={()=> Actions.register()}>Add Teacher</Text>
      <Text style={styles.textstyle} onPress={()=> Actions.addsubject()}>Add Subject</Text>
      <Text style={styles.textstyle} onPress={()=> Actions.studentsignup()}>Add Student</Text>
      <Text style={styles.textstyle} onPress={()=> Actions.addclass()}>Add Class</Text>
      <View style={{flexDirection:"row", flex:1, marginRight:50, marginLeft:20}}>
        <Card style={styles.mycard}>
          <TouchableOpacity onPress={()=> Actions.select()}>
    <View style={styles.cardView}>
    <Icon name="qr-scanner"  ios='ios-qr-scanner' android="md-qr-scanner" style={{fontSize: 30}} />
       <Text style={styles.welcome}> Generate QR Code</Text> 
   
    </View>
    </TouchableOpacity>
   </Card>
   <Card style={styles.mycard}  >
   <TouchableOpacity onPress={()=> Actions.studentlist()}>
    <View style={styles.cardView} >
    <Icon
  name="paper"  ios='ios-paper' android="md-paper" style={{fontSize: 30}} />
       <Text style={styles.welcome}> View all Students</Text> 
   
    </View>
    </TouchableOpacity>
   </Card>

   </View>
   <View>

   </View>
   
    
    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
    fontWeight: 'bold'
  },
  mycard:{
    marginRight:30,
    width:"50%",
    padding:10,
    height:"20%",
    borderRadius:5,
    shadowColor: "#fff",
    shadowOpacity:0.5,
    shadowRadius:5,

   
   
},
cardView:{
   flexDirection:"row",
   padding:5
  },
  textstyle: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
    
  }
});
export default Principalscreen;

